module.exports = {
    apiUrl: process.env.API_URL,
    apiDiscoverUrl: process.env.API_DISCOVER_URL,
    notificationApiUrl: process.env.NOTIFICATION_API_URL,
    eventApiUrl: process.env.EVENT_API_URL,
    apiMetaUrl: process.env.API_META_URL,
    metaToken: 'eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJhcHBzIjpbImFwaV9tZXRhIl0sImF1ZCI6InByb3hpbWl0eSIsImV4cCI6NDc0MzYyMDgyOCwiaWF0IjoxNTkwMDIwODI4LCJpc3MiOiJwcm94aW1pdHkiLCJqdGkiOiJjYmE1MzU1NC1jOGRhLTRlNmEtOTZlNi0yZDg4YmQyNDU4ZmEiLCJuYmYiOjE1OTAwMjA4MjcsInN1YiI6Im1ldGEgYmF0Y2giLCJ0eXAiOiJhY2Nlc3MifQ.2dZpV2UaMTnG6RqQlSWPwwSJ9WoSz77NxHmpBdQ5HKkgCmvAJnhcZOTfjW5dOX2Q_OcwpxRmWLYMyqIRykYoOw',
    port: process.env.PORT,
    logGroupName: process.env.LOG_GROUP_NAME,
    chimeLogGroupName: process.env.CHIME_LOG_GROUP_NAME,
    // DO NOT CHANGE THE PORTS IN .env-cmdrd.json file
}


// Local        - ./node_modules/.bin/env-cmd -e local nodemon server.js
// Development  - ./node_modules/.bin/env-cmd -e development pm2 start server.js --name digiarc_dev
// QA           - ./node_modules/.bin/env-cmd -e qa pm2 start server.js --name digiarc_qa
// Stage        - ./node_modules/.bin/env-cmd -e stage pm2 start server.js --name digiarc_stage
// Production   - ./node_modules/.bin/env-cmd -e production pm2 start server.js --name digiarc_prod