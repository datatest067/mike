const express = require("express");
const bodyParser = require("body-parser");
var fileupload = require("express-fileupload");
const cors = require("cors");
const config = require('./config');
const app = express();
const fs = require('fs');

//var corsOptions = {
//    origin: ["http://localhost:8081", "https://mychime.com/"]
//};
var corsOptions = {
    origin: "http://localhost:8081"
};

apiUrl = config.apiUrl;
apiDiscoverUrl = config.apiDiscoverUrl;
eventApiUrl = config.eventApiUrl;
notificationApiUrl = config.notificationApiUrl;
apiMetaUrl = config.apiMetaUrl;
logGroupName = config.logGroupName;
chimeLogGroupName = config.chimeLogGroupName;

metaToken = config.metaToken;

async = require('asyncawait/async');
await = require('asyncawait/await');

//app.use(cors(corsOptions));
app.use(cors());
app.options('*', cors());

// Parse request of content-type - application/json
app.use(bodyParser.json());

// Parse request of content-type - application/x-wwww-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

// Parse request of content-type - application/multipart-fordata
app.use(fileupload());
// Simple Route
app.get('/', (req, res) => {
    res.json({ message: "Welcome to API Web #4"});
});

app.get('/api-end-point', (req, res) => {
    res.json({ endPoint: apiUrl });
});

require("./app/routes/signup")(app);
require("./app/routes/group")(app);
require("./app/routes/discover")(app);
require("./app/routes/adminUser")(app);
require("./app/routes/adminEvent")(app);
require("./app/routes/open")(app);
require("./app/routes/user")(app);
require("./app/routes/groupcall")(app);
require("./app/routes/onBoarding")(app);
app.use('/api/adminGroup', require('./app/controllers/admingroup.controller'));
app.use('/api/organization', require('./app/controllers/organization.controller'));
app.use('/api/events', require('./app/controllers/event.controller'));
app.use('/api/notification', require('./app/controllers/notification.controller'));
// Set port, listen for request
const PORT = config.port;
app.listen(PORT, () => {
    console.log(`Server is running on PORT ${PORT}.`);
});

