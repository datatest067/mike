module.exports = {
  GLOBAL: {
    SOMETHING_WENT_WRONG: {
      status: 422,
      message: 'Something went wrong !!!',
    },
    SUCCESS: {
      status: 200,
      message: 'Success',
    },
    ERROR: {
      status: 422,
      message: 'Error',
    },
    FETCH_DATA_ERROR: {
      status: 422,
      message: 'Something went wrong while fetching data',
    },
    DELETE_DATA_ERROR: {
      status: 422,
      message: 'Something went wrong while deleting data',
    },
    DATA_NOT_FOUND: {
      status: 404,
      message: 'Requested data not found',
    },
    VALIDATION_ERROR: {
      status: 422,
      message: 'Invalid form data, please correct it and try again',
    },
  }
}
