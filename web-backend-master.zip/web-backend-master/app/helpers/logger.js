const { createLogger, format, transports } = require('winston');
const CloudWatchTransport = require('winston-aws-cloudwatch');

const cloudLogGroupName = logGroupName ? logGroupName : "da-logs";
const logStream = "da-dev-logs-stream";
const cloudwatchRegion = "us-east-1";
var startTime = new Date().toISOString();

const logger = new createLogger({
  format: format.combine(
    format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    format.metadata({ fillExcept: ['message', 'level', 'timestamp', 'label'] })
  ),
  transports: [
    new CloudWatchTransport({
      cloudLogGroupName,
      // logStreamName: logStream,
      logStreamName: function () {
        // Spread log streams across dates as the server stays up
        let date = new Date().toISOString().split('T')[0];
        return `${cloudLogGroupName}-${date}-${crypto.createHash('md5').update(startTime).digest('hex')}`;
      },
      createLogGroup: true,
      createLogStream: true,
      submissionInterval: 2000,
      submissionRetryCount: 1,
      batchSize: 20,
      awsConfig: {
        region: cloudwatchRegion
      }
    })
  ]
});

logger.on('finish', (finish) => {
  console.log('logger finish------>', finish);
})


module.exports = logger;