const {check, validationResult, body} = require('express-validator');
const {Organizations} = require('aws-sdk');

module.exports = app => {
  const group = require("../controllers/group.controller.js");
  var router = require("express").Router();

  // Get group list
  var groupListValidation = [
    check('page').not().isEmpty().withMessage('please provide page number'),
  ];
  router.get("/grouplist", groupListValidation, group.getGroupList);

  // Get single group details
  var groupExtendedValidation = [
    check('group_id').not().isEmpty().withMessage('please provide group id'),
  ];
  router.get("/groupextended", groupExtendedValidation, group.getGroupExtended);

  // Get single group member list
  var searchGroupMemberValidation = [
    check('group_id').not().isEmpty().withMessage('please provide group id'),
  ];
  router.get("/searchgroupmember", searchGroupMemberValidation, group.searchGroupMember);

  // Leave group
  router.delete("/leavegroup/:id", group.leaveGroup);
  
  // Delete group
  router.delete("/deletegroup/:id", group.deleteGroup);

  // Delete group member
  router.post("/deletegroupmember/", group.deleteGroupMember);

  // Join group
  router.post("/joingroup", group.joinGroup);

  // Mute Group
  var muteGroup = [
    check('group_id').not().isEmpty().withMessage('please provide group id'),
  ];
  router.post("/mutegroup", muteGroup, group.muteGroup);

  // Unmute group
  router.delete("/unmutegroup/:id", group.unmutegroup);
  
  // Make Owner
  var makeOwner = [
    check('group_id').not().isEmpty().withMessage('please provide group id'),
    check('user_id').not().isEmpty().withMessage('please provide user id'),
  ];
  router.post("/makeowner", makeOwner, group.makeOwner);

  // Change User Role
  var changeUserRole = [
    check('group_id').not().isEmpty().withMessage('please provide group id'),
    check('user_id').not().isEmpty().withMessage('please provide user id'),
  ];
  router.post("/changeuserrole", changeUserRole, group.changeUserRole);

  // Create new group
  var createGroupValidation = [
    check('organization_id').not().isEmpty().withMessage('please provide organization id'),
    check('name').not().isEmpty().withMessage('please provide group name')
  ];
  router.post("/create", createGroupValidation, group.createGroup);

  // Update group data
  var updateGroupValidation = [
    check('organization_id').not().isEmpty().withMessage('please provide organization id'),
    check('name').not().isEmpty().withMessage('please provide group name')
  ];
  router.post("/update", updateGroupValidation, group.updateGroup);

  // Search Organizations group member
  var searchGroupMemberValidation = [
    check('organization_id').not().isEmpty().withMessage('please provide organization id'),
    check('group_id').not().isEmpty().withMessage('please provide group id'),
  ];
  router.get("/search-members/:organization_id/:group_id/:page/:search?", searchGroupMemberValidation, group.searchMembers);

  // Send invitation for group
  var groupMemberInvitationValidation = [
    check('group_id').not().isEmpty().withMessage('please provide group id'),
    check('identifier').not().isEmpty().withMessage('please provide identifier'),
  ];
  router.get("/invite-member/:group_id/:identifier", groupMemberInvitationValidation, group.inviteMember);

  // Cancle invitation for group
  var cancelGroupMemberInvitationValidation = [
    check('group_id').not().isEmpty().withMessage('please provide group id'),
    check('identifier').not().isEmpty().withMessage('please provide identifier'),
  ];
  router.get("/cancel-member-invitation/:group_id/:identifier", cancelGroupMemberInvitationValidation, group.cancelMemberInvitation);

  // Create new event for group call
  var createGroupEvent = [
//    check('call_type').not().isEmpty().withMessage('please provide call type'),  
//    check('group_id').not().isEmpty().withMessage('please provide group id'),
    check('group_id').optional({checkFalsy: true}),
    check('type').not().isEmpty().withMessage('please provide event type'),
  ];
  router.post("/create-event", createGroupEvent, group.createGroupEvent);

  // Get organization list
  router.get("/organizationlist", group.getOrganizationList);

  app.use("/api/group", router);
};
