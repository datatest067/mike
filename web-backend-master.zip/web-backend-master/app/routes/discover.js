const {check, validationResult, body} = require('express-validator');

module.exports = app => {
    const discover = require("../controllers/discover.controller.js");
    var router = require("express").Router();

    // Get all discover data
    router.get("/alldiscover", discover.alldiscover);

    // Get default discover data
    router.get("/defaultdiscover", discover.defaultDiscover);

    // Get organization discover data
    router.get("/organizationdiscover", discover.organizationDiscover);

    // Get group discover data
    router.get("/groupdiscover", discover.groupDiscover);

    // Get event discover data
    router.get("/eventdiscover", discover.eventDiscover);

    // Get people discover data
    router.get("/peoplediscover", discover.peopleDiscover);

    app.use("/api/discover", router);
};
