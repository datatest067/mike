const { check, validationResult , body} = require('express-validator');

module.exports = app => {
    
    const call = require("../controllers/groupcall.controller.js");
    
    var  router = require("express").Router();

    router.post("/", call.getOrCreate);

    var inviteGroup = [
        check('identifier').not().isEmpty().withMessage('please provide identifier'),
        check('eventId').not().isEmpty().withMessage('please provide event id'),
    ];
    router.post("/invite-member", inviteGroup, call.inviteGroup);

    var joinEvent = [
        check('eventId').not().isEmpty().withMessage('please provide event id'),
    ];
    router.post("/join", joinEvent, call.joinEvent);

    var guestJoinEvent = [
        check('name').not().isEmpty().withMessage('please provide valid name'),
        check('challenge').not().isEmpty().withMessage('please provide valid challenge'),
        check('challenge_type').not().isEmpty().withMessage('please provide valid challenge type'),
        check('jwt').not().isEmpty().withMessage('please provide valid jwt'),
    ];
    router.post("/guest-join", guestJoinEvent, call.guestJoinEvent);

    app.use("/api/meeting", router);   

};