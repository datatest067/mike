const {check, validationResult, body} = require('express-validator');

module.exports = app => {
  const signup = require("../controllers/signup.controller.js");
  var router = require("express").Router();

  // Create a new signup
  var signupValidation = [
    check('name', 'please enter valid name.').trim().escape().matches(/^[a-zA-Z][a-zA-Z ]*$/).withMessage('name should be contain only alphabets and white space.'),
    check('email').isEmail().withMessage('please enter valid email address.'),
    check('country').not().isEmpty().withMessage('please select country.'),
    check('mobile_phone_number').matches(/^(\+){1}[1-9]{1}[0-9]{2,14}$/).withMessage('enter valid phone number with country code.'),
    check('password', 'password must be at least 8+ chars long').isLength({min: 8})
      .matches(/^\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])\S*$/).withMessage('password must contain one lower case letter, one upper case letter and one digit.'),
    body('password_confirmation', 'password and confirm password must match.').custom((value, {req}) => {
      if(req.body.password === value) {
        return true;
      } else {
        return false;
      }
    })
  ];
  router.post("/", signupValidation, signup.create);

  // Confirm OTP is valid or not
  var otpValidation = [
    check('otp').not().isEmpty().isLength({min: 6, max: 6}).withMessage('please enter valid code.'),
  ];
  router.post("/confirm", otpValidation, signup.validateOtp);

  app.use("/api/signup", router);
};
