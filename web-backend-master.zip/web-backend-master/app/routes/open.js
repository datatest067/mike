const { check, validationResult, body } = require('express-validator');

module.exports = app => {
  const open = require("../controllers/open.controller.js");
  var router = require("express").Router();

  // Login user
  var loginValidation = [
    check('email').isEmail().not().isEmpty().withMessage('please enter valid email address.'),
    check('password').not().isEmpty().withMessage('please enter password.'),
  ];
  router.post("/login", loginValidation, open.login);

  // Get countries list
  router.post("/countries", open.getCountries);

  // Get timezone list
  router.post("/timezone", open.getTimezone);

  // Get terms of service
  router.get("/termsofservice", open.getTermsofservice);

  // Send password reset link
  var resetValidation = [
    check('email').isEmail().not().isEmpty().withMessage('please enter valid email address.'),
  ];
  router.post("/send-reset-link", resetValidation, open.sendResetLink);

  // Resend OTP
  router.post("/resend-otp", resetValidation, open.resendOtp);

  // Verify Password
  var resetValidation = [
    check('email').isEmail().not().isEmpty().withMessage('please enter valid email address.'),
    check('otp').not().isEmpty().isLength({ min: 6 }).withMessage('please enter valid two factror token.'),
  ];
  router.post("/verify-reset-password", resetValidation, open.verifyPasswordOtp);

  // Password reset
  var resetValidation = [
    check('password_confirmation').not().isEmpty().withMessage('please enter valid email address.'),
    check('password').not().isEmpty().isLength({ min: 8 }).withMessage('please enter password.'),
    check('reset_password_token').not().isEmpty().withMessage('token expired for reset password.'),
  ];
  router.post("/reset-password", resetValidation, open.resetPassword);

  // Check organization code
  router.get("/:id/chekorgcode", open.chekOrgCode);
  
  // Seat request 
  router.post("/seatnotify", open.seatNotifyRequest);
  
  // get session detail
  router.get("/get-user-session", open.getSessionDetail);

  // Error log
  router.post("/error-log", open.errorlog);
  router.post("/chime-error-log", open.chimeErrorLog);
//  router.get("/chime-log-groups", open.chimeLogGroups);

  app.use("/api/open", router);
};
