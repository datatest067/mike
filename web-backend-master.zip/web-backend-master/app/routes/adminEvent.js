module.exports = app => {
    const event = require("../controllers/adminevent.controller");
    var router = require("express").Router();

    // Get all events data
    router.get("/allevent", event.AllEvents);

    // Invite to event
    router.post("/eventinvite", event.InviteEvent);

    // update event privacy
    router.patch("/eventprivacy", event.EventPrivacy);

    // Update Event details
    router.put("/updatevent", event.EditEvent);

    // Get all events members
    router.get("/geteventmembers", event.EventMembers);

    // search members
    router.get("/searchmembers", event.SearchMembers);

    // search members
    router.post("/kickmember", event.KickMember);

    app.use("/api/adminEvent", router);
};
