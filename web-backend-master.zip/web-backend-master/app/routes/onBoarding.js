module.exports = app => {
	const onBoarding = require("../controllers/onboarding.controller");
	var router = require("express").Router();
	// send invites to the onboarding users
	router.post("/invite", onBoarding.onBoardingInvites);
	app.use("/api/onboarding", router);
}