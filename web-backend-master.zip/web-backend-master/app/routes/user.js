const {check, validationResult, body} = require('express-validator');
const {Organizations} = require('aws-sdk');

module.exports = app => {
  const user = require("../controllers/user.controller.js");
  var router = require("express").Router();

  // Get profile of current user
  var profileValidation = [
    check('token').not().isEmpty().withMessage('token is required.'),
  ];
  router.post("/profile", profileValidation, user.profile);

  // Get profile data
  router.get("/getprofile", user.getProfile);

  // Get current user time zone
  router.get("/currenttimezone", user.currentTimeZone);

  // Get single uise profile
  router.post("/getsingleprofile", user.getSingleProfile);

  // Update Profile data
  router.post("/updateprofile", user.updateProfile);

  // Update email address
  router.post("/updateemail", user.updateEmail);

  // Update phone number
  router.post("/updatephone", user.updatePhone);

  // Check phone OTP number
  router.post("/checkphoneotp", user.checkPhoneOTP);

  // Update password
  router.post("/updatepassword", user.updatePassword);

  // Get Organizations list
  var orgValidation = [
    check('token').not().isEmpty().withMessage('token is required.'),
  ];
  router.post("/organizations", orgValidation, user.myOrganizations);

  app.use("/api/user", router);

};