const {check, validationResult, body} = require('express-validator');

module.exports = app => {
    const user = require("../controllers/adminuser.controller.js");
    var router = require("express").Router();

    // Get all user data
    router.get("/:organization_id/alluser", user.alluser);
    router.get("/:organization_id/orgdetail", user.orgDetail);
    router.get("/:organization_id/userdetail", user.userDetail);
    router.post("/:organization_id/:user_id/changerole", user.changeUserRole);
    router.post("/:organization_id/:user_id/remove-org-user", user.removeUserFromOrg);
    router.get("/:organization_id/all-groups", user.getAllGroups);

    app.use("/api/admin", router);
};
