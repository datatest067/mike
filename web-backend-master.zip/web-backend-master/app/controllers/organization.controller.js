var express = require('express');
var router = express.Router();
const util = require('util');
const axios = require('axios');
const request = require('request');
const CONST = require('../helpers/constants');

// Check organization subscription for current user
router.get('/:id/check-subscription', function (req, res) {

  const organizationId = req.params.id ? req.params.id : '';
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + `organizations/mine?page_size=5000`,
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };
  axios(options).then(result => {
    let is_subscribed = false;
    let is_muted = false;
    try {
      const organizations = result.data.entries.map(d => d.identifier);
      const muted = result.data.entries.filter(d => d.identifier === organizationId).map(data => data.notification_status);
      if (muted[0]) {
        is_muted = muted[0] === 'muted' ? true : false;
      }
      is_subscribed = organizations.includes(organizationId);
    } catch (error) {
      console.log(error);
    }
    const response = { ...CONST.GLOBAL.SUCCESS, data: { is_subscribed, is_muted } };
    res.status(200).json(response);
  }).catch(err => {
    const response = { ...CONST.GLOBAL.ERROR, type: err.response.statusText.toLowerCase(), message: err.response.statusText };
    res.status(422).json(response);
  });

});

// Subscribe the organization for current user
router.get('/:id/subscribe', async function (req, res) {

  const requestPromise = util.promisify(request);
  let responseData = CONST.GLOBAL.SOMETHING_WENT_WRONG;

  try {
    // Subscribe user to the organization
    const organizationId = req.params.id ? req.params.id : '';
    req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
    const optionsSubscribe = {
      url: apiUrl + `organizations/${organizationId}/join`,
      method: "POST",
      headers: {
        "content-type": "application/json",
        "Authorization": "Bearer " + req.headers.authorization,
        "User-Agent": req.headers['user-agent']
      },
      json: true
    };
    const subscribeRes = await requestPromise(optionsSubscribe);
    if (subscribeRes.statusCode >= 200 && subscribeRes.statusCode < 300) {
      responseData = { ...CONST.GLOBAL.SUCCESS, is_subscribed: true, organizationId: organizationId, message: 'Organization subscribed successfully' };
    } else {
      responseData = { ...CONST.GLOBAL.ERROR, message: subscribeRes.body.error };
      return res.status(422).json(responseData);
    }

    // Get notifications for current user
    req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
    const optionsNotificationList = {
      url: notificationApiUrl + `notifications?page_size=5000&page=1`,
      method: "GET",
      headers: {
        "content-type": "application/json",
        "Authorization": "Bearer " + req.headers.authorization,
        "User-Agent": req.headers['user-agent']
      },
      json: true
    };
    const notificationRes = await requestPromise(optionsNotificationList);
    let notificationData = [];
    let notificationId = null;
    if (notificationRes.statusCode >= 200 && notificationRes.statusCode < 300) {
      notificationData = notificationRes.body.entries.filter(notif => notif.type == 'organization_invitation');
    }
    // Find the invitation notification
    const temp = notificationData.every(n => {
      if (n.actions[0] && n.actions[0].identifier) {
        if (n.actions[0].identifier == organizationId) {
          notificationId = n.identifier;
          return true;
        }
      }
    });

    // Delete notification if exists
    if (notificationId) {
      req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
      const notifDelOptions = {
        url: notificationApiUrl + `notifications/${notificationId}`,
        method: "DELETE",
        headers: {
          "content-type": "application/json",
          "Authorization": "Bearer " + req.headers.authorization,
          "User-Agent": req.headers['user-agent']
        },
        json: true
      };
      await requestPromise(notifDelOptions);
    }
  } catch (error) {
    responseData = { ...CONST.GLOBAL.ERROR, message: error.message };
  }

  res.status(responseData.status).json(responseData);

});


// Unsubscribe the organization for current user
router.get('/:id/unsubscribe', function (req, res) {

  const organizationId = req.params.id ? req.params.id : '';
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + `organizations/${organizationId}/join`,
    method: "DELETE",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  axios(options).then(result => {

    const response = { ...CONST.GLOBAL.SUCCESS, is_subscribed: false, organizationId: organizationId, message: 'Organization unsubscribed successfully' };
    res.status(200).json(response);

  }).catch(err => {
    let message = err.response.statusText;
    const response = { ...CONST.GLOBAL.ERROR, type: err.response.statusText.toLowerCase(), message: message };
    res.status(422).json(response);
  });

});

// Get organization details
router.get('/:id/details', function (req, res) {

  const organizationId = req.params.id ? req.params.id : '';
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + `organizations/${organizationId}/extended`,
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  axios(options).then(result => {

    const response = { ...CONST.GLOBAL.SUCCESS, data: result.data };
    res.status(200).json(response);

  }).catch(err => {
    const response = { ...CONST.GLOBAL.ERROR, type: err.response.statusText.toLowerCase(), message: err.response.statusText };
    res.status(422).json(response);
  });

});

// Update organization details
router.patch('/:id/update', function (req, res) {

  // console.log(req.files.org_image)
  // console.log(req.files.org_BBimage)
  // console.log(req.body)
  // return;
  const organizationId = req.params.id ? req.params.id : '';
  const formData = {
    additional_link : req.body.additional_link ? req.body.additional_link : '',
    country : req.body.country ? req.body.country : '',
    country_code : req.body.country_code ? req.body.country_code : '',
    description : req.body.description ? req.body.description : '',
    email : req.body.email ? req.body.email : '',
    give_url : req.body.give_url ? req.body.give_url : '',
    main_phone_number : req.body.main_phone_number ? req.body.main_phone_number : '',
    name : req.body.name ? req.body.name : '',
    subname : req.body.subname ? req.body.subname : '',
    visibility : req.body.visibility ? req.body.visibility : '',
    address : {
      city : req.body.city ? req.body.city : '',
      postalcode : req.body.postalcode ? req.body.postalcode : '',
      state : req.body.state ? req.body.state : '',
      street : req.body.address ? req.body.address : '',
    }
  }

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + `organizations/${organizationId}`,
    method: "patch",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    form: formData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {

        if (req.files != null) {

          if (req.files.org_image != undefined) {
            req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
            const orgImageOptions = {
              url: apiUrl + 'organizations/' + organizationId + '/avatar',
              method: "put",
              headers: {
                "content-type": "application/octet-stream",
                "Authorization": "Bearer " + req.headers.authorization,
                "User-Agent": req.headers['user-agent']
              },
              body: req.files.org_image.data,
            };

            request(orgImageOptions, function (errorImage, responseImage, bodyImage) {
              if (!errorImage) {
                if (responseImage.statusCode >= 200 && responseImage.statusCode < 300) {
                  const responseData = { ...CONST.GLOBAL.SUCCESS, data: bodyImage };
                  if (req.files.org_BBimage == undefined) {
                    res.status(200).json(responseData);
                  }
                } else {
                  const responseData = { ...CONST.GLOBAL.ERROR, message: bodyImage.error.message, type: bodyImage.error.type };
                  res.status(422).json(responseData);
                }
              } else {
                res.status(422).json(errorImage);
              }
            });

          }

          if (req.files.org_BBimage != undefined) {
            req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
            const orgBBImageOptions = {
              url: apiUrl + 'organizations/' + organizationId + '/billboard',
              method: "put",
              headers: {
                "content-type": "application/octet-stream",
                "Authorization": "Bearer " + req.headers.authorization,
                "User-Agent": req.headers['user-agent']
              },
              body: req.files.org_BBimage.data,
            };

            request(orgBBImageOptions, function (errorBBImage, responseBBImage, bodyBBImage) {
              if (!errorBBImage) {
                if (responseBBImage.statusCode >= 200 && responseBBImage.statusCode < 300) {
                  const responseData = { ...CONST.GLOBAL.SUCCESS, data: bodyBBImage };
                  res.status(200).json(responseData);
                } else {
                  const responseData = { ...CONST.GLOBAL.ERROR, message: bodyBBImage.error.message, type: bodyBBImage.error.type };
                  res.status(422).json(responseData);
                }
              } else {
                res.status(422).json(errorBBImage);
              }
            });

          }
        }
        else {
          const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
          res.status(200).json(responseData);
        }
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error.message, type: body.error.type };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });

});

router.get('/:id/states', function (req, res) {

  const country = req.params.id;

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiMetaUrl + `states_or_provinces/${country}`,
    method: "GET",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + metaToken,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error.message, type: body.error.type };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });

});

router.get('/search-members/:organization_id/:search?', function (req, res) {

  const organization_id = req.params.organization_id;
  const group_id = '97937592-ac61-11ea-a579-4e6c9a54feb5';
  const search = req.params.search ? req.params.search : '';

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + `organizations/${organization_id}/members/search/with/group/${group_id}/status?search[name]=${search}`,
    method: "GET",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error.message, type: body.error.type };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });

});

router.get('/invite-member/:organization_id/:identifier', function (req, res) {

  const organization_id = req.params.organization_id;
  const identifier = req.params.identifier;
  const formData = { "identifiers": [identifier] };
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiUrl + `organizations/${organization_id}/invite`,
    method: "POST",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    body: formData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error.message, type: body.error.type };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
});

router.get('/cancel-member-invitation/:organization_id/:identifier', function (req, res) {

  const organization_id = req.params.organization_id;
  const identifier = req.params.identifier;
  const formData = { "identifiers": [identifier] };
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiUrl + `organizations/${organization_id}/invite`,
    method: "DELETE",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    body: formData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error.message, type: body.error.type };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
});

router.get('/events/:organization_id', function (req, res) {

  const organization_id = req.params.organization_id;
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: eventApiUrl + `organizations/${organization_id}/events/mine`,
    method: "GET",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
});

router.get('/:id/notifications/status', function (req, res) {

  const organization_id = req.params.id;
  const responseData = { ...CONST.GLOBAL.SUCCESS, muted: true };
  res.status(200).json(responseData);

});

router.get('/:id/notifications/mute', function (req, res) {

  const organization_id = req.params.id;
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + `organizations/${organization_id}/notifications/mute`,
    method: "POST",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, muted: true, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, muted: false, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.SOMETHING_WENT_WRONG, muted: false, message: error };
      res.status(422).json(responseData);
    }
  });
});

router.get('/:id/notifications/resume', function (req, res) {

  const organization_id = req.params.id;
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + `organizations/${organization_id}/notifications/mute`,
    method: "DELETE",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, muted: false, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, muted: false, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.SOMETHING_WENT_WRONG, muted: false, message: error };
      res.status(422).json(responseData);
    }
  });
});

// Load more events
router.get('/events/:id/:page', function (req, res) {

  const organization_id = req.params.id;
  const page = req.params.page ? req.params.page : 1;
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: eventApiUrl + `organizations/${organization_id}/events?page=${page}&page_size=25`,
    method: "GET",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, muted: false, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, muted: false, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.SOMETHING_WENT_WRONG, muted: false, message: error };
      res.status(422).json(responseData);
    }
  });
});

module.exports = router;
