var express = require('express');
var router = express.Router();
const request = require('request');
const CONST = require('../helpers/constants');
const util = require('util');

// admin group list
router.get('/list', function (req, res) {

  const organizationId = req.query.organizationId ? req.query.organizationId : 1;
  const page = req.query.page ? req.query.page : 1;
  const query = req.query.search ? req.query.search : '';
  const order = req.query.order ? req.query.order : 'name';
  const dir = req.query.dir ? req.query.dir : 'asc';

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  
  const options = {
    url: apiUrl + `admin/organizations/${organizationId}/groups?search[name]=${encodeURIComponent(query)}&page=${page}&order=${order}&dir=${dir}`,
    method: "GET",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.SOMETHING_WENT_WRONG, message: error };
      res.status(422).json(responseData);
    }
  });
});

// change visibility
router.post('/:id/visibility', function (req, res) {

  const id = req.params.id ? req.params.id : '';
  const formData = {
    visibility: req.body.visibility ? req.body.visibility : '',
  }
  
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiUrl + `admin/groups/${id}`,
    method: "PATCH",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    body: formData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: {identifier: id, visibility: req.body.visibility} };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });
});

// Assign new group owner
router.post('/assign-group-woner', function (req, res) {
  
  const identifier = req.body.identifier ? req.body.identifier : '';
  const group_id = req.body.group_id ? req.body.group_id : '';

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const formData = {
    "owner_identifier": identifier
  };

  const options = {
    url: apiUrl + `admin/groups/${group_id}/owner/${identifier}`,
    method: "PUT",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    body: formData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: {identifier, role : 'owner'} };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
});

// Invite group member list
router.post('/invitememberlist', function (req, res) {
  
  const organization_id = req.body.organization_id ? req.body.organization_id : '';
  const group_id = req.body.group_id ? req.body.group_id : '';
  const page = req.body.page ? req.body.page : '';
  const search = req.body.search ? encodeURIComponent(req.body.search) : '';

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiUrl + `organizations/${organization_id}/members/search/with/group/${group_id}/status?page=${page}&search[name]=${search}`,
    method: "GET",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
});

// Invite group member
router.get('/invite-member/:group_id/:identifier', function (req, res) {
  
  const group_id = req.params.group_id ? req.params.group_id : '';
  const identifier = req.params.identifier ? req.params.identifier : '';

  const formData = { "identifiers": [identifier] };

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + `admin/groups/${group_id}/invite`,
    method: "POST",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    body: formData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: {identifier, subscription_status: 'invited'} };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
});

// Cancle invite group member
router.get('/cancel-member-invitation/:group_id/:identifier', function (req, res) {
  
  const group_id = req.params.group_id ? req.params.group_id : '';
  const identifier = req.params.identifier ? req.params.identifier : '';

  const formData = { "identifiers": [identifier] };

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + `admin/groups/${group_id}/invite`,
    method: "DELETE",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    body: formData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: {identifier, subscription_status: null} };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
});

// delete group
router.delete('/:id/delete', function (req, res) {

  const id = req.params.id ? req.params.id : '';
  
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiUrl + `admin/groups/${id}`,
    method: "DELETE",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: {identifier: id} };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });
});

// group detail
router.get('/:id/extend', function (req, res) {

  const id = req.params.id ? req.params.id : '';
  
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiUrl + `admin/groups/${id}`,
    method: "GET",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });
});

// group member list
router.get('/memberlist', function (req, res) {

  const id = req.query.id ? req.query.id : '';
  const page = req.query.page ? req.query.page : 1;
  const query = req.query.search ? req.query.search : '';

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  
  const options = {
    url: apiUrl + `admin/groups/${id}/members?search[name]=${encodeURIComponent(query)}&page=${page}`,
    method: "GET",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.SOMETHING_WENT_WRONG, message: error };
      res.status(422).json(responseData);
    }
  });
});

// change visibility
router.post('/role', function (req, res) {

  const groupId = req.body.id ? req.body.id : '';
  const memberId = req.body.member ? req.body.member : '';
  const formData = {
    role: req.body.role ? req.body.role : '',
  }
  
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiUrl + `admin/groups/${groupId}/members/${memberId}/role`,
    method: "PUT",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    body: formData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: {identifier: memberId, role: req.body.role} };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });
});

// Delete user from group
router.post('/kick', function (req, res) {

  const groupId = req.body.id ? req.body.id : '';
  const memberId = req.body.member ? req.body.member : '';
  
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiUrl + `admin/groups/${groupId}/members/${memberId}/kick`,
    method: "DELETE",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: {identifier: memberId} };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });
});

// Group event list
router.get('/eventlist', function (req, res) {

  const groupId = req.query.groupId ? req.query.groupId : 1;
  const page = req.query.page ? req.query.page : 1;
  const query = req.query.search ? req.query.search : '';

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  
  const options = {
    url: eventApiUrl + `/admin/groups/${groupId}/events?search[name]=${encodeURIComponent(query)}&page=${page}`,
    method: "GET",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.SOMETHING_WENT_WRONG, message: error };
      res.status(422).json(responseData);
    }
  });
});

// Delete an event
router.post('/deleteevent', function (req, res) {

  const identifier = req.body.identifier ? req.body.identifier : '';
  const recursion = req.body.recursion ? req.body.recursion : '';
  const type = req.body.type ? req.body.type : '';

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  var deleteUrl = eventApiUrl + `admin/events/${identifier}`;
  if(type && type === 'recurring') {
    var deleteUrl = eventApiUrl + `events/recurring/${recursion}`;
  }

  const options = {
    url: deleteUrl,
    method: "DELETE",
    headers: {
      "content-type": "application/json",
      "Authorization": `Bearer ${req.headers.authorization}`,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: { identifier, recursion, type } };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });
});

// Invite Event participants
router.post('/eventinvitation/:type', function (req, res) {

  const type = req.params.type === 'invite' ? 'invite' : 'cancel';
  const method = type === 'invite' ? 'POST' : 'DELETE';
  const event_id = req.body.event_id ? req.body.event_id : '';
  const identifier = req.body.identifier ? req.body.identifier : '';
  const recursion = req.body.recursion ? req.body.recursion : '';
  const event_type = req.body.event_type ? req.body.event_type : '';

  const formData = { "identifiers": [identifier] };
  var url = eventApiUrl + `events/${event_id}/invite`;
  if(event_type && event_type === 'recurring') {
    var url = eventApiUrl + `events/${event_id}/invite_recurring`;
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url, method,
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    body: formData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: { type, identifier } };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.SOMETHING_WENT_WRONG, message: error };
      res.status(422).json(responseData);
    }
  });
});

// Create an admin event
router.post('/:type/:id/create-event', function (req, res) {

  const id = req.params.id ? req.params.id : '';
  const formData = {
    name: req.body.name ? req.body.name : '',
    description: req.body.description ? req.body.description : '',
    begins_at: req.body.begins_at ? req.body.begins_at : '',
    ends_at: req.body.ends_at ? req.body.ends_at : '',
    type: req.body.type ? req.body.type : '',
    visibility: req.body.visibility ? req.body.visibility : '',
  }
  if(req.body.frequency && req.body.frequency !== '' && req.body.frequency === 'weekly_days') {
    formData['frequency'] = [req.body.frequency, req.body.frequencyDay];
  }
  else if(req.body.frequency && req.body.frequency !== '') {
    formData['frequency'] = req.body.frequency;
  }
  if(req.body.frequency && req.body.frequency !== '' && req.body.repeat_amount && req.body.repeat_amount !== '') {
    formData['repeat_amount'] = parseInt(req.body.repeat_amount);
  }
  const eventHost = req.params.type == 'group' ? 'groups' : 'organizations';
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: eventApiUrl + `admin/${eventHost}/${id}/events`,
    method: "POST",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    body: formData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });
});

// Update an admin event
router.patch('/:id/update-event', function (req, res) {

  const eventId = req.params.id ? req.params.id : '';
  const formData = req.body ? req.body : {};
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: eventApiUrl + `admin/events/${eventId}`,
    method: "PATCH",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    form: formData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });
});

router.post('/create-group', function (req, res) {
  
  var postData = {
    affiliation_mode: "open",
    name: req.body.name,
    description: req.body.description,
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiUrl + 'admin/organizations/' + req.body.organization_id + '/groups',
    method: "post",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    form: postData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {

        // Upload group image
        if (req.files != null) {
          req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

          const imageOptions = {
            url: apiUrl + 'admin/groups/' + body.identifier + '/avatar',
            method: "put",
            headers: {
              "content-type": "application/octet-stream",
              "Authorization": "Bearer " + req.headers.authorization,
              "User-Agent": req.headers['user-agent']
            },
            body: req.files.image.data,
          };

          request(imageOptions, function (errorImg, responseImg, bodyImg) {
            if (!errorImg) {
              if (responseImg.statusCode >= 200 && responseImg.statusCode < 300) {
                const responseData = { ...CONST.GLOBAL.SUCCESS, data: bodyImg };
                res.status(200).json(responseData);
              } else {
                const responseData = { ...CONST.GLOBAL.ERROR, data: {message: bodyImg.error.message, type: bodyImg.error.type} };
                res.status(422).json(responseData);
              }
            } else {
              res.status(422).json(errorImg);
            }
          });

        } else {
          const responseData = { ...CONST.GLOBAL.SUCCESS, data: { message: 'Group created successfully'}};
          res.status(200).json(responseData);
        }

      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, data: {message: body.error.message, type: body.error.type} };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
});

router.post('/update-group', function (req, res) {
  
  var postData = {
    affiliation_mode: req.body.affiliation_mode,
    name: req.body.name,
    description: req.body.description,
    status: req.body.status,
    visibility: req.body.visibility,
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiUrl + 'admin/groups/' + req.body.group_id,
    method: "put",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    form: postData,
    json: true
  };

  var returnBody = {
    identifier: req.body.group_id,
    name: req.body.name,
    description: req.body.description,
    avatar_url: req.body.image_preview,
  }

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {

        // Upload group image
        if (req.files != null) {
          req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

          const imageOptions = {
            url: apiUrl + 'admin/groups/' + req.body.group_id + '/avatar',
            method: "put",
            headers: {
              "content-type": "application/octet-stream",
              "Authorization": "Bearer " + req.headers.authorization,
              "User-Agent": req.headers['user-agent']
            },
            body: req.files.image.data,
          };

          request(imageOptions, function (errorImg, responseImg, bodyImg) {
            if (!errorImg) {
              if (responseImg.statusCode >= 200 && responseImg.statusCode < 300) {
                const responseData = { ...CONST.GLOBAL.SUCCESS, data: returnBody };
                res.status(200).json(responseData);
              } else {
                const responseData = { ...CONST.GLOBAL.ERROR, message: bodyImg.error.message, type: bodyImg.error.type };
                res.status(422).json(responseData);
              }
            } else {
              res.status(422).json(errorImg);
            }
          });
        } else {
          const responseData = { ...CONST.GLOBAL.SUCCESS, data: returnBody, message: 'Group upadted successfully' };
          res.status(200).json(responseData);
        }
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error.message, type: 'error' };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
});

module.exports = router;
