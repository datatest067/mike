const request = require('request');
const { validationResult } = require('express-validator');
const CONST = require('../helpers/constants');

exports.AllEvents = (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: eventApiUrl + 'admin/organizations/' + req.query.organization_id + '/events?search[name]=' + encodeURIComponent(req.query.search) + '&page_size=25&page=' + req.query.page + '&order=' + req.query.order+ '&dir=' + req.query.dir,
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.InviteEvent = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const formData = {
    identifiers: req.body.identifiers ? req.body.identifiers : [],
  }
  const options = {
    url: req.body.inviteType == 'individual' ? eventApiUrl + '/events/' + req.body.event_id + '/invite' : eventApiUrl + '/events/' + req.body.event_id + '/invite_recurring',
    method: "post",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    body: formData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.EventPrivacy = (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: eventApiUrl + '/admin/events/' + req.body.event_id,
    method: "patch",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    body: req.body ? req.body : {},
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.EditEvent = (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: eventApiUrl + '/admin/events/' + req.body.identifier,
    method: "PUT",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    body: req.body ? req.body : {},
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.EventMembers = (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: eventApiUrl + '/admin/events/' + req.query.event_id + '/members',
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.SearchMembers = (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: eventApiUrl + '/admin/events/' + req.query.event_id + '/members?search[name]=' + req.query.searchText + '&attendance_status=' + req.query.attendance_status,
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.KickMember = (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  const event_id = req.body.id ? req.body.id : '';
  const memberId = req.body.member ? req.body.member : '';

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: eventApiUrl + `admin/events/${event_id}/members/${memberId}/kick`,
    method: "DELETE",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: { identifier: memberId } };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });
};