// Create Signup call
const request = require('request');
const {check, validationResult} = require('express-validator');
const CONST = require('../helpers/constants');

exports.create = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if(!errors.isEmpty()) {
    return res.status(422).json({errors: errors.array()});
  }
  
  var postData = {
    name: req.body.name,
    country: req.body.country,
    time_zone: req.body.time_zone,
    mobile_phone_number: req.body.mobile_phone_number,
    email: req.body.email,
    password: req.body.password,
    password_confirmation: req.body.password_confirmation,
    organization_code: req.body.organization_code,
    affiliation_code: req.body.organization_code,
    accepted_tos: req.body.accepted_tos,
    visibility: req.body.visibility,
  }

  const options = {
    url: apiUrl + 'registration',
    method: "post",
    headers: {
      "content-type": "application/json"
    },
    form: postData,
    json: true
  };

  request(options, function (error, response, body) {
    if(!error) {
      if(response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = {...CONST.GLOBAL.SUCCESS, data: body};
        res.status(200).json(responseData);
      } else {
        const responseData = {...CONST.GLOBAL.ERROR, message: body.error};
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};


exports.validateOtp = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if(!errors.isEmpty()) {
    return res.status(422).json({errors: errors.array()});
  }


  const options = {
    url: apiUrl + 'registration',
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      "Accept": "application/json"
    },
    form: {two_factor_token: req.body.otp},
    json: true
  };

  request(options, function (error, response, body) {
    if(!error) {
      if(response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = {...CONST.GLOBAL.SUCCESS, data: body};
        res.status(200).json(responseData);
      } else {
        const responseData = {...CONST.GLOBAL.ERROR, message: body.error};
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};
