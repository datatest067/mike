// Create Signup call
//const axios = require('axios');
const request = require('request');
const { check, validationResult } = require('express-validator');
const CONST = require('../helpers/constants');

exports.profile = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + 'user/profile/extended',
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.body.token,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.getProfile = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + 'user/profile/extended',
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.currentTimeZone = (req, res) => {

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: `${apiUrl}user/time_zone`,
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": `Bearer ${req.headers.authorization}`,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.getSingleProfile = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }

  const user_id = req.body.user_id;

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + `user/${user_id}/profile`,
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.updateProfile = async (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }

  var notification = [];
  if (req.body.email_noti === 'true') {
    notification.push('email');
  }
  if (req.body.push_noti === 'true') {
    notification.push('push');
  }
  if (req.body.text_noti === 'true') {
    notification.push('sms');
  }
  var postData = {
    country: req.body.country,
    name: req.body.name,
    bio: req.body.bio,
    time_zone: req.body.timezone,
    date_of_birth: req.body.birth_date,
    notification_methods: notification
  }

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + 'user/profile',
    method: "put",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    body: postData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        if (req.files != null) {
          req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
          const imageOptions = {
            url: apiUrl + 'user/avatar',
            method: "put",
            headers: {
              "content-type": "application/octet-stream",
              "Authorization": "Bearer " + req.headers.authorization,
              "User-Agent": req.headers['user-agent']
            },
            // form: postData,
            body: req.files.image.data,
          };
          request(imageOptions, function (error, response, body) {
            if (!error) {
              if (response.statusCode >= 200 && response.statusCode < 300) {
                const responseData = { ...CONST.GLOBAL.SUCCESS, data: body, message: 'Profile successfully updated', type: 'success' };
                res.status(200).json(responseData);
              } else {
                const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
                res.status(422).json(responseData);
              }
            } else {
              res.status(422).json(error);
            }
          });
        }
        else {
          const responseData = { ...CONST.GLOBAL.SUCCESS, data: body, message: 'Profile successfully updated', type: 'success' };
          res.status(200).json(responseData);
        }
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.updateEmail = (req, res) => {

  var postData = {
    email: req.body.email,
  }

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + 'user/email',
    method: "put",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    form: postData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body, message: 'Email address successfully changed', type: 'success' };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error.message, type: 'error' };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.updatePhone = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }

  var postData = {
    mobile_phone_number: req.body.mobile,
  }

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + 'user/mobile_phone_number/begin',
    method: "PUT",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    form: postData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body, message: 'OTP successfully sent', type: 'success' };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error.message, type: 'error' };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.checkPhoneOTP = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }

  var postData = {
    two_factor_token: req.body.otp,
  }

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + 'user/mobile_phone_number',
    method: "PUT",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    form: postData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body, message: 'Phone successfully changed', type: 'success' };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: 'Opps that doesn\'t seem like the right code.', type: 'error' };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.updatePassword = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }

  var postData = {
    current_password: req.body.current_password,
    password: req.body.password,
    password_confirmation: req.body.password_confirmation,
  }

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + 'user/password',
    method: "PUT",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    form: postData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body, message: 'Password successfully changed', type: 'success' };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error.message, type: 'error' };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.myOrganizations = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + 'organizations/mine?page=' + req.body.page + '&page_size=' + req.body.pageLimit,
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.body.token,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};
