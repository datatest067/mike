const request = require('request');
const { validationResult } = require('express-validator');
const CONST = require('../helpers/constants');

exports.onBoardingInvites = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const body = {
    users: req.body.users
  }
  const options = {
    url: `${apiUrl}organizations/${req.body.organizationId}/onboarding`,
    method: "post",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
    },
    body,
    json: true
  };
  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
  };