var express = require('express');
var router = express.Router();
const request = require('request');
const CONST = require('../helpers/constants');
const util = require('util');

// Create an event
router.post('/:type/:id/create', function (req, res) {

  const id = req.params.id ? req.params.id : '';
  const formData = {
    name: req.body.name ? req.body.name : '',
    description: req.body.description ? req.body.description : '',
    begins_at: req.body.begins_at ? req.body.begins_at : '',
    ends_at: req.body.ends_at ? req.body.ends_at : '',
    type: req.body.type ? req.body.type : '',
    visibility: req.body.visibility ? req.body.visibility : '',
  }
  if (req.body.frequency && req.body.frequency !== '' && req.body.frequency === 'weekly_days') {
    formData['frequency'] = [req.body.frequency, req.body.frequencyDay];
  }
  else if (req.body.frequency && req.body.frequency !== '') {
    formData['frequency'] = req.body.frequency;
  }
  if (req.body.frequency && req.body.frequency !== '' && req.body.repeat_amount && req.body.repeat_amount !== '') {
    formData['repeat_amount'] = parseInt(req.body.repeat_amount);
  }
  const eventHost = req.params.type == 'group' ? 'groups' : 'organizations';
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: eventApiUrl + `${eventHost}/${id}/events`,
    method: "POST",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    body: formData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });
});

// Update an event
router.patch('/:id/update', function (req, res) {

  const eventId = req.params.id ? req.params.id : '';
  const formData = req.body ? req.body : {};
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: eventApiUrl + `events/${eventId}`,
    method: "PATCH",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    form: formData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });
});

// Delete an event
router.post('/:id/delete', function (req, res) {

  const identifier = req.params.id ? req.params.id : '';
  const recursion = req.body.recursion ? req.body.recursion : '';
  const type = req.body.type ? req.body.type : '';
  const isAdmin = req.body.isAdmin ? req.body.isAdmin : '';

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  var deleteUrl = `events/${identifier}`;
  if (type && type === 'recurring') {
    var deleteUrl = `events/recurring/${recursion}`;
  }

  if (isAdmin)
    deleteUrl = eventApiUrl + `admin/` + deleteUrl;
  else
    deleteUrl = eventApiUrl + deleteUrl;

  const options = {
    url: deleteUrl,
    method: "DELETE",
    headers: {
      "content-type": "application/json",
      "Authorization": `Bearer ${req.headers.authorization}`,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: { identifier, recursion, type } };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });
});

// My events list
router.get('/mine/:page/:search?', function (req, res) {

  const page = req.params.page ? req.params.page : 1;
  const query = req.params.search ? req.params.search : '';

  const url = eventApiUrl + `events/mine?search[name]=${query}&page=${page}`;

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url,
    method: "GET",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.SOMETHING_WENT_WRONG, message: error };
      res.status(422).json(responseData);
    }
  });
});

// My events list
router.get('/member-list/:id/:page/:search/:isAdmin/:attendance_status', function (req, res) {
  const page = req.params.page ? req.params.page : 1;
  const id = req.params.id ? req.params.id : 'n.a';
  const search = req.params.search && req.params.search !== 'search' ? req.params.search : '';
  const isAdmin = req.params.isAdmin;
  const attendance_status = req.params.attendance_status;

  const url = isAdmin == 'true' ? eventApiUrl + `admin/events/${id}/members?page=${page}&page_size=25&search[name]=${search}&attendance_status=${attendance_status}` : eventApiUrl + `events/${id}/members?page=${page}&page_size=25&search[name]=${search}`;
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url,
    method: "GET",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.SOMETHING_WENT_WRONG, message: error };
      res.status(422).json(responseData);
    }
  });
});

// Event list
router.get('/list', function (req, res) {
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiUrl + `events`,
    method: "GET",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
});

// Event extended
router.get('/:id/extended', function (req, res) {

  const id = req.params.id;
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: eventApiUrl + `events/${id}/extended`,
    method: "GET",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body !== undefined ? body.error : 'Something went wrong' };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.SOMETHING_WENT_WRONG, message: error };
      res.status(422).json(responseData);
    }
  });
});

// Subscribe the event for current user
router.get('/:id/subscribe', async function (req, res) {

  const requestPromise = util.promisify(request);
  let responseData = CONST.GLOBAL.SOMETHING_WENT_WRONG;
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  try {
    const eventId = req.params.id ? req.params.id : '';
    const optionsJoin = {
      url: eventApiUrl + `events/${eventId}/attend`,
      method: "POST",
      headers: {
        "content-type": "application/json",
        "Authorization": "Bearer " + req.headers.authorization,
        "User-Agent": req.headers['user-agent']
      },
      json: true
    };

    const subscribeRes = await requestPromise(optionsJoin);
    if (subscribeRes.statusCode >= 200 && subscribeRes.statusCode < 300) {
      responseData = { ...CONST.GLOBAL.SUCCESS, data: { event: eventId } };
    } else {
      responseData = { ...CONST.GLOBAL.ERROR, message: subscribeRes.body.error };
      return res.status(422).json(responseData);
    }
    req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

    // Get notifications for current user
    const optionsNotificationList = {
      url: `${notificationApiUrl}notifications?page_size=5000&page=1`,
      method: "GET",
      headers: {
        "content-type": "application/json",
        "Authorization": `Bearer ${req.headers.authorization}`,
        "User-Agent": req.headers['user-agent']
      },
      json: true
    };
    const notificationRes = await requestPromise(optionsNotificationList);
    let notificationData = [];
    let notificationId = null;
    if (notificationRes.statusCode >= 200 && notificationRes.statusCode < 300) {
      notificationData = notificationRes.body.entries.filter(notif => notif.type === 'event_invitation');
    }
    // Find the invitation notification
    notificationData.every(n => {
      if (n.actions[0] && n.actions[0].identifier) {
        if (n.actions[0].identifier === eventId) {
          notificationId = n.identifier;
          return true;
        }
      }
    });
    req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

    // Delete notification if exists
    if (notificationId) {
      const notifDelOptions = {
        url: `${notificationApiUrl}notifications/${notificationId}`,
        method: "DELETE",
        headers: {
          "content-type": "application/json",
          "Authorization": `Bearer ${req.headers.authorization}`,
          "User-Agent": req.headers['user-agent']
        },
        json: true
      };
      await requestPromise(notifDelOptions);
    }
  } catch (error) {
    responseData = { ...CONST.GLOBAL.ERROR, message: error.message };
  }

  res.status(responseData.status).json(responseData);
});


// Unsubscribe the event for current user / remove from calendar
router.get('/:id/unsubscribe', function (req, res) {

  const eventId = req.params.id ? req.params.id : '';
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: eventApiUrl + `events/${eventId}/attend`,
    method: "DELETE",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: { event: eventId } };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });
});

// Invite or Cancel user invitation to event
router.post('/:id/invite', function (req, res) {

  const eventId = req.params.id ? req.params.id : '';
  const identifier = req.body.identifier ? req.body.identifier : '';
  const removeMember = req.body.removeMember ? true : false;
  const bodyMethod = req.body.method.toLocaleUpperCase();
  const method = (bodyMethod == 'DELETE') ? 'DELETE' : 'POST';
  let type = 'cancel';
  if (bodyMethod == 'POST') {
    type = 'invite';
  } else if (bodyMethod == 'RE-POST') {
    type = 're-invite';
  }

  let bodyData = { "identifiers": [identifier] };
  let url = eventApiUrl + `events/${eventId}/invite`;
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  // If member needs to be removed from event
  if (removeMember) {
    bodyData = {};
    url = eventApiUrl + `events/${eventId}/users/${identifier}`;
  }

  const options = {
    url, method,
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    body: bodyData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: { event: eventId, type, identifier } };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });

});

// Event breakout create
router.post('/:id/breakout', function (req, res) {

  const eventId = req.params.id ? req.params.id : '';
  const method = 'POST';
  const type = method == 'POST' ? 'invite' : 'cancel';
  const bodyData = {};
  const url = eventApiUrl + `events/${eventId}/breakouts`;
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url, method,
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    body: bodyData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });
});

// Get host list
router.get('/hosts', function (req, res) {
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiUrl + `hosts`,
    method: "GET",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });
});

// Event participants list limited by all current user organizations
router.get('/participants/organizations/:event_id/:page', function (req, res) {

  const page = req.params.page ? req.params.page : 1;
  const event_id = req.params.event_id ? req.params.event_id : 'n.a';
  const search = req.query.q ? req.query.q : '';

  const url = apiUrl + `organizations/members/search/with/event/${event_id}/status?page=${page}&search[name]=${search}`;
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url,
    method: "GET",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.SOMETHING_WENT_WRONG, message: error };
      res.status(422).json(responseData);
    }
  });
});

// Event participants list limited by organization or group
router.get('/participants/:host/:host_id/:event_id/:page', function (req, res) {

  const host = req.params.host == 'organization' ? 'organizations' : 'groups';
  const page = req.params.page ? req.params.page : 1;
  const event_id = req.params.event_id ? req.params.event_id : 'n.a';
  const host_id = req.params.host_id ? req.params.host_id : 'n.a';
  const search = req.query.q ? req.query.q : '';

  const url = apiUrl + `${host}/${host_id}/members/search/with/event/${event_id}/status?page=${page}&search[name]=${search}`;
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url,
    method: "GET",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.SOMETHING_WENT_WRONG, message: error };
      res.status(422).json(responseData);
    }
  });
});

// Invite Event participants
router.post('/participants/invitation/:type', function (req, res) {

  const type = req.params.type === 'invite' ? 'invite' : 'cancel';
  const method = type === 'invite' ? 'POST' : 'DELETE';
  const event_id = req.body.event_id ? req.body.event_id : 'n.a';
  const identifier = req.body.identifier ? req.body.identifier : 'n.a';
  const recursion = req.body.recursion ? req.body.recursion : 'n.a';
  // console.log(identifier)
  // console.log(recursion)

  const formData = { "identifiers": [identifier] };
  var url = eventApiUrl + `events/${event_id}/invite`;
  if (recursion && recursion !== 'n.a') {
    var url = eventApiUrl + `events/${event_id}/invite_recurring`;
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url, method,
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    body: formData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: { type, identifier } };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.SOMETHING_WENT_WRONG, message: error };
      res.status(422).json(responseData);
    }
  });
});

// Calendar contents
router.get('/:id/calendar/:type', function (req, res) {

  const type = req.params.type === 'add' ? 'add' : 'remove';
  const id = req.params.id ? req.params.id : 'n.a';
  const url = eventApiUrl + `events/${id}/calendar/${type}`;
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url,
    method: "GET",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    }
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.SOMETHING_WENT_WRONG, message: error };
      res.status(422).json(responseData);
    }
  });
});
module.exports = router;
