const AWS = require('aws-sdk');
const { v4: uuid } = require('uuid');
const { check, validationResult } = require('express-validator');
const request = require('request');
const CONST = require('../helpers/constants');

// Store created meetings in a map so attendees can join by meeting title
const meetingTable = {};

exports.getOrCreate = async (req, res) => {
//   AWS.config.update({
//     accessKeyId: 'AKIA3ATK3BZPS3XZAFA5',
//     secretAccessKey: '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',
//   });
  // You must use "us-east-1" as the region for Chime API and set the endpoint.
  const chime = new AWS.Chime({ region: 'us-east-1' });
  chime.endpoint = new AWS.Endpoint('https://service.chime.aws.amazon.com/console');
  //    console.log(chime);
  var id = req.body.id;
  var attendeeId = req.body.attendeeId;
  var meetingResponse = null;
  var attendeeResponse = null;
  var userType = 'attendee';
  try {
    if (id) {
      meetingResponse = await chime.getMeeting({
        MeetingId: id,
      }).promise();
    } else {
      meetingResponse = await chime.createMeeting({
        ClientRequestToken: uuid(),
        MediaRegion: 'us-west-1' // Specify the region in which to create the meeting.
      }).promise();
      userType = 'groupAdmin';
    }

    if (attendeeId) {
      attendeeResponse = await chime.getAttendee({
        MeetingId: meetingResponse.Meeting.MeetingId,
        AttendeeId: attendeeId,
      }).promise();
    } else {
      attendeeResponse = await chime.createAttendee({
        MeetingId: meetingResponse.Meeting.MeetingId,
        ExternalUserId: `${uuid().substring(0, 8)}##${userType}##${req.body.name}`.substring(0, 64) // Link the attendee to an identity managed by your application.
      }).promise();
    }
    //
    //    console.log(meetingResponse);
    //    


    var data = {
      meeting: meetingResponse,
      attendee: attendeeResponse
    };
    //    
    //    console.log(attendeeResponse);
    //    
    res.status(200).json(data);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
  /*try {
      if (req.body.action === 'join') {
        
        // Look up the meeting by its title. If it does not exist, create the meeting.
        if (!meetingTable[req.body.title]) {
          meetingTable[req.body.title] = await chime.createMeeting({
            // Use a UUID for the client request token to ensure that any request retries
            // do not create multiple meetings.
            ClientRequestToken: uuid(),
            // Specify the media region (where the meeting is hosted).
            // In this case, we use the region selected by the user.
            MediaRegion: 'us-east-1',
            // Any meeting ID you wish to associate with the meeting.
            // For simplicity here, we use the meeting title.
            ExternalMeetingId: req.body.title.substring(0, 64),
          }).promise();
        }

        // Fetch the meeting info
        const meeting = meetingTable[req.body.title];

        // Create new attendee for the meeting
        const attendee = await chime.createAttendee({
          // The meeting ID of the created meeting to add the attendee to
          MeetingId: meeting.Meeting.MeetingId,

          // Any user ID you wish to associate with the attendeee.
          // For simplicity here, we use a random id for uniqueness
          // combined with the name the user provided, which can later
          // be used to help build the roster.
          ExternalUserId: `${uuid().substring(0, 8)}#${req.body.name}`.substring(0, 64),
        }).promise()

        // Return the meeting and attendee responses. The client will use these
        // to join the meeting.
        var data = {
          meeting: meeting,
          attendee: attendee
      };
        console.log(attendee);
  
      res.status(200).json(data);
      
      } else if (req.body.action === 'end') {
        // End the meeting. All attendee connections will hang up.
        await chime.deleteMeeting({
          MeetingId: meetingTable[req.body.title].Meeting.MeetingId,
        }).promise();
        res.status(200).json({});
      } else {
        res.status(404).json({});
      }
    } catch (err) {
      res.status(400).json({error: err.message});
    } */

};

exports.inviteGroup = async (req, res) => {

  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }

  const postData = { "identifiers": [req.body.identifier] };
  const eventId = req.body.eventId;

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: eventApiUrl + `events/${eventId}/invite/adhoc`,
    // url: notificationApiUrl + 'notifications/email',
    method: "POST",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    body: postData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: 'Invited successfully' };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });

};

exports.joinEvent = async (req, res) => {

  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  const eventId = req.body.eventId;

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: eventApiUrl + `events/${eventId}/join`,
    method: "POST",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });

};


exports.guestJoinEvent = async (req, res) => {

  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }

  const formData = {
    name: req.body.name,
    challenge: req.body.challenge,
    challenge_type: req.body.challenge_type,
    jwt: req.body.jwt
  };

  const options = {
    url: apiUrl + `sessions/guest`,
    method: "POST",
    headers: {
      "content-type": "application/json",
    },
    form: formData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const eventData = body;

        // Join the event API
        req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
        const eventOptions = {
          url: eventApiUrl + `events/${eventData.event.identifier}/join`,
          method: "POST",
          headers: {
            "content-type": "application/json",
            "Authorization": "Bearer " + eventData.jwt,
            "User-Agent": req.headers['user-agent']
          },
          json: true
        };

        request(eventOptions, function (error, response, body) {
          if (!error) {
            if (response.statusCode >= 200 && response.statusCode < 300) {
              const eventJoin = body;
              const responseData = { ...CONST.GLOBAL.SUCCESS, data: { eventData, eventJoin } };
              res.status(200).json(responseData);
            } else {
              const responseData = { ...CONST.GLOBAL.ERROR, eventJoinError: body.error, eventData };
              res.status(422).json(responseData);
            }
          } else {
            const responseData = { ...CONST.GLOBAL.ERROR, eventJoinError: error, eventData };
            res.status(422).json(responseData);
          }
        });

      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, eventJoinError: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });

};

