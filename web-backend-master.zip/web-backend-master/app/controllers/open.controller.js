// Create Signup call
const AWS = require('aws-sdk');
const request = require('request');
const { check, validationResult } = require('express-validator');
const CONST = require('../helpers/constants');
const logger = require("../helpers/logger");
const crypto = require('crypto');

AWS.config.update({ region: 'us-east-1' });

exports.login = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  var postData = {
    email: req.body.email,
    password: req.body.password,
  }

  const options = {
    url: apiUrl + 'sessions',
    method: "post",
    headers: {
      "content-type": "application/json"
    },
    form: postData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.getCountries = (req, res) => {

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiMetaUrl + 'countries?search=' + req.body.search,
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + metaToken,
      "User-Agent": req.headers['user-agent']
    },
    form: { search: 'us' },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.getTimezone = (req, res) => {

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiMetaUrl + 'countries/' + req.body.search,
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + metaToken,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.sendResetLink = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  var postData = {
    email: req.body.email,
  }

  const options = {
    url: apiUrl + 'password/reset',
    method: "post",
    headers: {
      "content-type": "application/json"
    },
    form: postData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });

};
exports.resendOtp = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  var postData = {
    email: req.body.email,
  }

  const options = {
    url: apiUrl + 'two_factor_token',
    method: "post",
    headers: {
      "content-type": "application/json"
    },
    form: postData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.verifyPasswordOtp = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  var postData = {
    email: req.body.email,
    two_factor_token: req.body.otp,
  }

  const options = {
    url: apiUrl + 'password/reset/verify',
    method: "put",
    headers: {
      "content-type": "application/json"
    },
    form: postData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};
exports.resetPassword = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  var postData = {
    password: req.body.password,
    password_confirmation: req.body.password_confirmation,
    reset_password_token: req.body.reset_password_token,
  }

  const options = {
    url: apiUrl + 'password/reset',
    method: "put",
    headers: {
      "content-type": "application/json"
    },
    form: postData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body, message: 'Passwoed changed successfully' };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.chekOrgCode = (req, res) => {

  const orgCode = req.params.id;

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + `organization_code/${orgCode}`,
    method: "GET",
    headers: {
      "content-type": "application/json",
      // "Authorization": "Bearer " + metaToken,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error.message, type: body.error.type, data: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.seatNotifyRequest = (req, res) => {

  var postData = {
    email: req.body.email,
    name: req.body.name,
  }

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + `organizations/${req.body.organization_identifier}/seats/request`,
    method: "post",
    headers: {
      "content-type": "application/json"
    },
    form: postData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });

};

async function ensureLogStream(cloudWatchClient, logStreamName, cloudLogGroupName) {

  const logStreamsResult = await cloudWatchClient.describeLogStreams({
    logGroupName: cloudLogGroupName,
    logStreamNamePrefix: logStreamName,
  }).promise();
  const foundStream = logStreamsResult.logStreams.find(s => s.logStreamName === logStreamName);
  if (foundStream) {
    return foundStream.uploadSequenceToken;
  }
  await cloudWatchClient.createLogStream({
    logGroupName: cloudLogGroupName,
    logStreamName: logStreamName,
  }).promise();
  return null;
};


exports.errorlog = async (req, res) => {

  const bodyData = req.body;
  const logData = { meta: bodyData, headers: req.headers };

  try {

    const isLocalHost = req.headers.host.includes("localhost") ? true : false;
    // const isLocalHost = true;

    if (!isLocalHost) {

      const cloudLogGroupName = logGroupName ? logGroupName : "da-logs";

      let streamDate = new Date().toISOString().split('T')[0];
      const logStreamName = `${streamDate}--${crypto.createHash('md5').update(streamDate).digest('hex')}`;

      var cloudWatchClient = new AWS.CloudWatchLogs({
        apiVersion: '2014-03-28'
      });

      let putLogEventsInput = {
        "logGroupName": cloudLogGroupName,
        "logStreamName": logStreamName
      };

      // Check or create new stream
      var uploadSequence = await ensureLogStream(cloudWatchClient, logStreamName, cloudLogGroupName);

      //get upload sequence
      if (uploadSequence) {
        putLogEventsInput["sequenceToken"] = uploadSequence;
      }
      const message = `[${bodyData.level}] ${bodyData.message} \n ${JSON.stringify(logData)}`;

      putLogEventsInput["logEvents"] = [{
        "message": message,
        "timestamp": new Date().getTime()
      }];

      let data = await cloudWatchClient.putLogEvents(putLogEventsInput).promise();

    }

    res.status(200).json({ message: 'success' });
  } catch (error) {
    console.error("error", error.message)
    res.status(422).json({ error: error.message });

  }

};

exports.chimeErrorLog = async (req, res) => {

  const bodyData = req.body;
  let meetingId = bodyData.meetingId;
  let attendeeId = bodyData.attendeeId;
  let logs = bodyData.logs;
  //  console.log(req);
  const cloudLogGroupName = chimeLogGroupName ? chimeLogGroupName : "da-chime-logs";
  const isLocalHost = req.headers.host.includes("localhost") ? true : false;
  
  try {

    
    // const isLocalHost = true;

    if (!isLocalHost) {

      

      const logStreamName = `ChimeSDKMeeting_${meetingId}_${attendeeId}`;
      //here is the log stream name of your log group.
      var cloudWatchClient = new AWS.CloudWatchLogs({
        apiVersion: '2014-03-28'
      });
      let putLogEventsInput = {
        "logGroupName": cloudLogGroupName,
        "logStreamName": logStreamName
      };
      //putLogEventsInput objey
      var uploadSequence = await ensureLogStream(cloudWatchClient, logStreamName, cloudLogGroupName);
      //get upload sequence
      if (uploadSequence) {
        putLogEventsInput["sequenceToken"] = uploadSequence;
      }
      var logEvents = [];
      //traverse log events
      if (logs.length > 0) {
        for (let i = 0; i < logs.length; i++) {
          var log = logs[i];
          var timestampIso = new Date(log.timestampMs).toISOString();
          var message = `${timestampIso} [${log.sequenceNumber}] [${log.logLevel}] [mid:
                ${meetingId.toString()}] [aid: ${attendeeId}]: ${log.message}`;
          logEvents.push({
            "message": message,
            "timestamp": log.timestampMs
          });
        }
        putLogEventsInput["logEvents"] = logEvents;
        //put data to cloudwatch
        let data = await cloudWatchClient.putLogEvents(putLogEventsInput).promise();
        //           console.log("data",data);
      }

    }

    res.status(200).json({ message: 'success', isLocalHost: isLocalHost });
  } catch (error) {
    console.error("error", error.message)
    res.status(422).json({ error: error.message, group : cloudLogGroupName, isLocalHost: isLocalHost, extra: error });

  }

};

exports.chimeLogGroups = async (req, res) => {

  
  //  console.log(req);
  const cloudLogGroupNamePrefix = "da-prod";
  
  try {
      var cloudwatchlogs = new AWS.CloudWatchLogs({
        apiVersion: '2014-03-28'
      });
      var params = {
        limit: 10,
        logGroupNamePrefix: cloudLogGroupNamePrefix
       };
      const data = await cloudwatchlogs.describeLogGroups(params).promise();
      var sts = new AWS.STS();
      const stsData  = await sts.getCallerIdentity({}).promise();
       
    res.status(200).json({ message: 'success', data: data , config: AWS.config, stsData: stsData});
  } catch (error) {
    console.error("error", error.message)
    res.status(422).json({ error: error.message, extra: error, config: AWS.config });

  }

};
exports.getTermsofservice = (req, res) => {
  const options = {
    url: apiUrl + 'terms_of_service',
    method: "get",
    headers: {
      "content-type": "application/json"
    },
    json: true
  };
  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.getSessionDetail = (req, res) => {
  const options = {
    url: apiUrl + 'sessions/' + req.headers.authorization,
    method: "get",
    headers: {
      "content-type": "application/json"
    },
    json: true
  };
  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};
