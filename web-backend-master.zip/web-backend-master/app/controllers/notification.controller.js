var express = require('express');
var router = express.Router();
const request = require('request');
const CONST = require('../helpers/constants');

router.get('/list/:page', function (req, res) {

  const page = req.params.page ? req.params.page : 1;

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: notificationApiUrl + `notifications?page_size=25&page=${page}`,
    method: "GET",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });
});

router.post('/accept-reject', function (req, res) {

  const acceptUrl = req.body.url
  const id = req.body.id;
  const method = req.body.method;

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: acceptUrl,
    method: method,
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: { id, status: 'done' } };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });
});

router.put('/manage-read', function (req, res) {

  const id = req.body.id;
  const status = req.body.status === 'read' ? 'read' : 'unread';

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: notificationApiUrl + `notifications/${id}/${status}`,
    method: "PUT",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: { id, status } };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });
});

router.get('/unread/count', function (req, res) {

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: notificationApiUrl + `notifications/count/unread`,
    method: "GET",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        let unreadCount = body.count;
        if (unreadCount > 10) unreadCount = '10+';
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: { unreadCount } };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });
});

router.get('/:id/delete', function (req, res) {

  const id = req.params.id;

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: notificationApiUrl + `notifications/${id}`,
    method: "DELETE",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: { id, status: true } };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });
});
module.exports = router;
