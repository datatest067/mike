// Create Signup call
const path = require('path');
const request = require('request');
const util = require('util');
const { check, validationResult } = require('express-validator');
const fs = require('fs');
const CONST = require('../helpers/constants');

exports.getGroupList = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiUrl + 'groups/mine?search[name]=' + encodeURIComponent(req.query.search) + '&page=' + req.query.page + '&filter=' + req.query.filter,
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.getGroupExtended = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiUrl + 'groups/' + req.query.group_id + '/extended',
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.searchGroupMember = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiUrl + 'groups/' + req.query.group_id + '/members?search[name]=' + encodeURIComponent(req.query.search) + '&page=' + req.query.page,
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.createGroup = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }

  var postData = {
    affiliation_mode: "open",
    name: req.body.name,
    description: req.body.description,
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiUrl + 'organizations/' + req.body.organization_id + '/groups',
    method: "post",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    form: postData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {

        // Upload group image
        if (req.files != null) {
          req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

          const imageOptions = {
            url: apiUrl + 'groups/' + body.identifier + '/avatar',
            method: "put",
            headers: {
              "content-type": "application/octet-stream",
              "Authorization": "Bearer " + req.headers.authorization,
              "User-Agent": req.headers['user-agent']
            },
            body: req.files.image.data,
          };

          request(imageOptions, function (errorImg, responseImg, bodyImg) {
            if (!errorImg) {
              if (responseImg.statusCode >= 200 && responseImg.statusCode < 300) {
                const responseData = { ...CONST.GLOBAL.SUCCESS, data: bodyImg };
                res.status(200).json(responseData);
              } else {
                const responseData = { ...CONST.GLOBAL.ERROR, message: bodyImg.error.message, type: bodyImg.error.type };
                res.status(422).json(responseData);
              }
            } else {
              res.status(422).json(errorImg);
            }
          });

        } else {
          const responseData = { ...CONST.GLOBAL.SUCCESS, message: 'Group created successfully' };
          res.status(200).json(responseData);
        }

      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error.message, type: body.error.type };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.updateGroup = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }

  var postData = {
    affiliation_mode: req.body.affiliation_mode,
    name: req.body.name,
    description: req.body.description,
    status: req.body.status,
    visibility: req.body.visibility,
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiUrl + 'groups/' + req.body.group_id,
    method: "put",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    form: postData,
    json: true
  };

  var returnBody = {
    identifier: req.body.group_id,
    name: req.body.name,
    avatar_url: req.body.image_preview,
  }

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {

        // Upload group image
        if (req.files != null) {
          req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

          const imageOptions = {
            url: apiUrl + 'groups/' + req.body.group_id + '/avatar',
            method: "put",
            headers: {
              "content-type": "application/octet-stream",
              "Authorization": "Bearer " + req.headers.authorization,
              "User-Agent": req.headers['user-agent']
            },
            body: req.files.image.data,
          };

          request(imageOptions, function (errorImg, responseImg, bodyImg) {
            if (!errorImg) {
              if (responseImg.statusCode >= 200 && responseImg.statusCode < 300) {
                const responseData = { ...CONST.GLOBAL.SUCCESS, data: returnBody };
                res.status(200).json(responseData);
              } else {
                const responseData = { ...CONST.GLOBAL.ERROR, message: bodyImg.error.message, type: bodyImg.error.type };
                res.status(422).json(responseData);
              }
            } else {
              res.status(422).json(errorImg);
            }
          });

        } else {
          const responseData = { ...CONST.GLOBAL.SUCCESS, data: returnBody, message: 'Group upadted successfully' };
          res.status(200).json(responseData);
        }
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.errors.detail, type: 'error' };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.leaveGroup = (req, res) => {
  // Validate request
  const group_id = req.params.id;
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiUrl + 'groups/' + group_id + '/join',
    method: "delete",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: { id: group_id } };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.deleteGroup = (req, res) => {
  // Validate request
  const group_id = req.params.id;
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiUrl + `groups/${group_id}`,
    method: "delete",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: { id: group_id } };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.deleteGroupMember = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiUrl + `groups/${req.body.group_id}/users/${req.body.user_id}`,
    method: "delete",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: { user_id: req.body.user_id } };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.joinGroup = async (req, res) => {

  const requestPromise = util.promisify(request);
  let responseData = CONST.GLOBAL.SOMETHING_WENT_WRONG;

  try {
    var groupId = req.body.group_id;
    var postData = {
      group_id: req.body.group_id,
    }
    req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

    const optionsJoin = {
      url: apiUrl + 'groups/' + req.body.group_id + '/join',
      method: "POST",
      headers: {
        "content-type": "application/json",
        "Authorization": "Bearer " + req.headers.authorization,
        "User-Agent": req.headers['user-agent']
      },
      form: postData,
      json: true
    };

    const subscribeRes = await requestPromise(optionsJoin);
    if (subscribeRes.statusCode >= 200 && subscribeRes.statusCode < 300) {
      responseData = { ...CONST.GLOBAL.SUCCESS, data: { id: req.body.group_id } };
    } else {
      responseData = { ...CONST.GLOBAL.ERROR, message: subscribeRes.body.error };
      return res.status(422).json(responseData);
    }
    req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

    // Get notifications for current user
    const optionsNotificationList = {
      url: `${notificationApiUrl}notifications?page_size=5000&page=1`,
      method: "GET",
      headers: {
        "content-type": "application/json",
        "Authorization": `Bearer ${req.headers.authorization}`,
        "User-Agent": req.headers['user-agent']
      },
      json: true
    };
    const notificationRes = await requestPromise(optionsNotificationList);
    let notificationData = [];
    let notificationId = null;
    if (notificationRes.statusCode >= 200 && notificationRes.statusCode < 300) {
      notificationData = notificationRes.body.entries.filter(notif => notif.type === 'group_invitation');
    }
    // Find the invitation notification
    notificationData.every(n => {
      if (n.actions[0] && n.actions[0].identifier) {
        if (n.actions[0].identifier === groupId) {
          notificationId = n.identifier;
          return true;
        }
      }
    });

    // Delete notification if exists
    if (notificationId) {
      req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
      const notifDelOptions = {
        url: `${notificationApiUrl}notifications/${notificationId}`,
        method: "DELETE",
        headers: {
          "content-type": "application/json",
          "Authorization": `Bearer ${req.headers.authorization}`,
          "User-Agent": req.headers['user-agent']
        },
        json: true
      };
      await requestPromise(notifDelOptions);
    }
  } catch (error) {
    responseData = { ...CONST.GLOBAL.ERROR, message: error.message };
  }

  res.status(responseData.status).json(responseData);
};

exports.muteGroup = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }

  var postData = {
    group_id: req.body.group_id,
  }

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + 'groups/' + req.body.group_id + '/notifications/mute',
    method: "POST",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    form: postData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: { id: req.body.group_id, notification_status: 'muted' } };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.unmutegroup = (req, res) => {
  // Validate request
  const group_id = req.params.id;
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + 'groups/' + group_id + '/notifications/mute',
    method: "delete",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: { id: group_id, notification_status: 'unmuted' } };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.makeOwner = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }

  var postData = {
    owner_identifier: req.body.user_id,
  }

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + `/groups/${req.body.group_id}/owner`,
    method: "PUT",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    form: postData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.changeUserRole = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }

  var postData = {
    owner_identifier: req.body.user_id,
  }

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + `/groups/${req.body.group_id}/role`,
    method: "PUT",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    form: postData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.searchMembers = (req, res) => {
  // Validate request
  const organization_id = req.params.organization_id;
  const group_id = req.params.group_id;
  const page = req.params.page;
  const search = req.params.search ? encodeURIComponent(req.params.search) : '';
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + `organizations/${organization_id}/members/search/with/group/${group_id}/status?page=${page}&search[name]=${search}`,
    method: "GET",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.inviteMember = (req, res) => {
  // Validate request
  const group_id = req.params.group_id;
  const identifier = req.params.identifier;
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }

  const formData = { "identifiers": [identifier] };

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + `groups/${group_id}/invite`,
    method: "POST",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    body: formData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.cancelMemberInvitation = (req, res) => {
  // Validate request
  const group_id = req.params.group_id;
  const identifier = req.params.identifier;
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }

  const formData = { "identifiers": [identifier] };

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: apiUrl + `groups/${group_id}/invite`,
    method: "DELETE",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    body: formData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.createGroupEvent = async (req, res) => {

  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ ...CONST.GLOBAL.ERROR, errors: errors.array() });
  }
  const group_id = req.body.group_id;
  var postData = {
    begins_at: req.body.begins_at,
    ends_at: req.body.ends_at,
    name: req.body.name,
    type: req.body.type
  }
  
  let url = eventApiUrl + `groups/${group_id}/call`;
  if(req.body.call_type === 'user'){
      url = eventApiUrl + `users/${group_id}/call`;
  }if(req.body.call_type === 'event'){
      url = eventApiUrl + `event/now`;
  }

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url,
    method: "POST",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    form: postData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const eventData = body;
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: { eventData } };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });
}

exports.getOrganizationList = (req, res) => {
  // Validate request

  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  const options = {
    url: `${apiUrl}organizations/mine?page_size=5000`,
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": `Bearer ${req.headers.authorization}`,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const eventData = body;
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: { eventData } };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      const responseData = { ...CONST.GLOBAL.ERROR, message: error };
      res.status(422).json(responseData);
    }
  });
};
