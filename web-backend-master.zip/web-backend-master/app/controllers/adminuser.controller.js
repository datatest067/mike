// Create Signup call
//const axios = require('axios');
const path = require('path');
const request = require('request');
const { check, validationResult } = require('express-validator');
const fs = require('fs');
const CONST = require('../helpers/constants');

exports.alluser = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  let orderField = 'order'
  if(req.query.order === 'role'){
      orderField = 'order[organization_subscriptions]'
  }
  let url = apiUrl + 'admin/organizations/'+ req.params.organization_id +'/members?page_size=25&page=' + req.query.page + '&'+orderField+'=' + encodeURIComponent(req.query.order) ;
      url += '&dir=' + encodeURIComponent(req.query.dir);
  if(req.query.search){
      url += '&search[name]=' + encodeURIComponent(req.query.search);
  }
//  else{
//      url += '&search[name]=' ;
//  }
//  console.log(url)
  const options = {
    url: url,
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body ? body.error: 'Something went wrong.' , data: response};
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.getAllGroups = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  let url = apiUrl + 'admin/search/organizations/'+ req.params.organization_id +'/members/'+ req.query.user_id +'/administerable_groups/grouped_by_organizations?user_for_status_identifier=' + req.query.user_id;
//  let url = apiUrl + 'organizations/'+ req.params.organization_id +'/groups?page_size=25&page=' + req.query.page //+ '&order=' + encodeURIComponent(req.query.order);
  if(req.query.search){
      url += '&search[name]=' + encodeURIComponent(req.query.search);
  }
  else{
      url += '&search[name]=' ;
  }
//  console.log(url)
  const options = {
    url: url,
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body ? body.error: 'Something went wrong.' , data: response};
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.orgDetail = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  let url = apiUrl + 'admin/organizations/'+ req.params.organization_id 

  const options = {
    url: url,
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.userDetail = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  let url = apiUrl + 'admin/organizations/'+ req.params.organization_id + '/members/' + req.query.user_id

  const options = {
    url: url,
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.changeUserRole = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  let url = apiUrl + 'admin/organizations/'+ req.params.organization_id + '/members/' + req.params.user_id + '/role'
  
  let formData = {
    role: req.body.role,
  };
  if(req.body.role === 'owner'){
      url = apiUrl + 'organizations/'+ req.params.organization_id + '/owner/' + req.params.user_id 
      formData = {}
  }
  const options = {
    url: url,
    method: "put",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    form: formData,
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.removeUserFromOrg = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;
  let url = apiUrl + 'admin/organizations/'+ req.params.organization_id + '/members/' + req.params.user_id + '/kick'
  
  const options = {
    url: url,
    method: "delete",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

