// Create Signup call
//const axios = require('axios');
const path = require('path');
const request = require('request');
const { check, validationResult } = require('express-validator');
const fs = require('fs');
const CONST = require('../helpers/constants');

exports.alldiscover = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiDiscoverUrl + 'discover/all?term=' + encodeURIComponent(req.query.search) + '&page_size=25&page=' + req.query.page,
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.defaultDiscover = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: `${apiDiscoverUrl}discover/default?page_size=25&page=${req.query.page}`,
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.organizationDiscover = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiDiscoverUrl + 'discover/organizations?term=' + encodeURIComponent(req.query.search) + '&page_size=25&page=' + req.query.page,
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.groupDiscover = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiDiscoverUrl + 'discover/groups?term=' + encodeURIComponent(req.query.search) + '&page_size=25&page=' + req.query.page,
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.eventDiscover = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiDiscoverUrl + 'discover/events?term=' + encodeURIComponent(req.query.search) + '&page_size=25&page=' + req.query.page,
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};

exports.peopleDiscover = (req, res) => {
  // Validate request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  req.headers['user-agent'] = `${req.headers['app-details']} (${req.headers['user-agent']})`;

  const options = {
    url: apiDiscoverUrl + 'discover/people?term=' + encodeURIComponent(req.query.search) + '&page_size=25&page=' + req.query.page,
    method: "get",
    headers: {
      "content-type": "application/json",
      "Authorization": "Bearer " + req.headers.authorization,
      "User-Agent": req.headers['user-agent']
    },
    json: true
  };

  request(options, function (error, response, body) {
    if (!error) {
      if (response.statusCode >= 200 && response.statusCode < 300) {
        const responseData = { ...CONST.GLOBAL.SUCCESS, data: body };
        res.status(200).json(responseData);
      } else {
        const responseData = { ...CONST.GLOBAL.ERROR, message: body.error };
        res.status(422).json(responseData);
      }
    } else {
      res.status(422).json(error);
    }
  });
};
