module.exports = {
    apiUrl: 'https://api-accounts.arcapp.dev/',
    apiDiscoverUrl: 'https://api-discover.arcapp.dev/',
    notificationApiUrl: 'https://api-notifications.arcapp.dev/',
    eventApiUrl: 'https://api-events.arcapp.dev/',
    apiMetaUrl: 'https://api-meta.arcapp.dev/',
    metaToken: 'eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJhcHBzIjpbImFwaV9tZXRhIl0sImF1ZCI6InByb3hpbWl0eSIsImV4cCI6NDc0MzYyMDgyOCwiaWF0IjoxNTkwMDIwODI4LCJpc3MiOiJwcm94aW1pdHkiLCJqdGkiOiJjYmE1MzU1NC1jOGRhLTRlNmEtOTZlNi0yZDg4YmQyNDU4ZmEiLCJuYmYiOjE1OTAwMjA4MjcsInN1YiI6Im1ldGEgYmF0Y2giLCJ0eXAiOiJhY2Nlc3MifQ.2dZpV2UaMTnG6RqQlSWPwwSJ9WoSz77NxHmpBdQ5HKkgCmvAJnhcZOTfjW5dOX2Q_OcwpxRmWLYMyqIRykYoOw',
    port: 8081,
}